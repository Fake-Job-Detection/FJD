import React from "react";
import "./ContactUs.css";

export default function ContactUs() {
    return (
        <div className="p1">
        <p>M.R.M.Omar - omar.2018527@iit.ac.lk </p>
        <br/>
        
        <p>Abdul Quadir Refa - abdul.2018472@iit.ac.lk </p>
        <br/>
       
        <p>S.K.D.P.Dinuwanthika - disney.2018370@iit.ac.lk</p>
        <br/>
        
        <p>A.Yogenthirarajah - akalya.2018374@iit.ac.lk </p>
        <br/>
        
        <p>Jawith Afrid - jawith.2018229@iit.ac.lk </p>
        <br/>
        
        <p>Thabitta Judixon - thabitta.2018600@iit.ac.lk</p>
     </div>
     
     
      
    );
}   