import React from 'react';
import '../../App.css';
import Footer from '../Footer';


function Alljobs() {
  return (
    <>
 <div className='hero-container'>
       
       <h3>Find all jobs</h3>
 </div>
      <Footer />
    </>
  );
}

export default Alljobs;