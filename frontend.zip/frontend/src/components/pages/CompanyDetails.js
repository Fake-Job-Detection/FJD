import React from "react";
import "./ComPreview.css";

export default function CompanyDetails() {
    return (
    <div className="preview">
            
    <table>
    <tr>
    <td colspan = '2'><h3><i>Company Details and Video</i></h3></td> 
    <br/>
      <br/>
      </tr>
     
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      </table> 
      </div>
      
      
    );
}   